﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Protocolo
{
    public class ConfigServidor
    {
        public static string ServerIpConfig = "ServerIpAddress";
        public static string ServerPortConfig = "ServerPort";
        public static string LocalIpConfig = "LocalIpAddress";
        public static string PictureFolder = "PictureFolder";
    }
}
